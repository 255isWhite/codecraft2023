#!/bin/sh
cd "$( dirname "$0" )"
sudo ./Robot_gui "python3 Demo/keyboard_demo.py" -m maps/2.txt